
redis-server /etc/redis/redis.conf
nohup celery -A basemodel.tasks worker --loglevel=info &
nohup /usr/local/inception-master/debug/mysql/bin/Inception --defaults-file=/etc/inc.cnf &


